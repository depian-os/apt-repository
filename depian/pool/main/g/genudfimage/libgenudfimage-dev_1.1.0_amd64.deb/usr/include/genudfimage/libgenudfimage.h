/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co., Ltd.
 *
 * Author:     zhangsheng<zhangsheng@uniontech.com>
 *
 * Maintainer: max-lv<lvwujun@uniontech.com>
 *             xushitong<xushitong@uniontech.com>
 *             dengkeyun<dengkeyun@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef LIB_GENUDFIMAGE_H_
#define LIB_GENUDFIMAGE_H_

#include <stdint.h>

/*
 * error code
 */
enum {
    GENUDFIMAGE_OK = 0,
    GENUDFIMAGE_INVALID_VAL,
    GENUDFIMAGE_INVALID_NAME,
    GENUDFIMAGE_DESTRUCT_FAILED,
    GENUDFIMAGE_OOM,
    GENUDFIMAGE_EXPECT_UNIQ_FILE,
    GENUDFIMAGE_EXPECT_FILE,
    GENUDFIMAGE_WRITE_FAILED,
    GENUDFIMAGE_INVALID_VERSION
};

#define MAX_LABEL_LEN 32
#define MAX_MEDIA_LEN 16
#define VERSION_LEN   5

/*
 * User intput parameters
 */
typedef struct {
    char label[MAX_LABEL_LEN];          /* Specify the UDF label */
    char version[VERSION_LEN];          /* Specify the UDF version to use */
    uint32_t   blocksize;               /* Specify the size of blocks in bytes */
    char media[MAX_MEDIA_LEN];          /* TODO: Specify media type, must 'dvdr' now */ // TODO: enum
} genudfimage_options;

int genudfimage_open(const char *pathname, const genudfimage_options *options);
int genudfimage_multisession_open(const char *pathname, const genudfimage_options *options,
                               uint32_t last_sess_start, uint32_t next_sess_start, const char *devname);
int genudfimage_import(int fd, const char *filename);
int genudfimage_multisession_import(int fd, const char *filename, const char *parent);
int genudfimage_make(int fd);
int genudfimage_close(int fd);

#endif /* LIB_GENUDFIMAGE_H_ */
