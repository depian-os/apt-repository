ISO 标准配置解析库, 相关文件位于 /usr/share/xml/iso-codes/, 目前实现了
对 iso_3166.xml 的解析从而可以获取国家和地区的相关信息.
