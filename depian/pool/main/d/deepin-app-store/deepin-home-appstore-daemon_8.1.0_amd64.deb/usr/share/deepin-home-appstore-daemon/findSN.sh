#!/bin/bash
declare -a devSNs=()
#查询除u盘以外的存储设备
function find_alldev(){

	devInfos=`ls -ll /sys/block/ | grep -v usb | grep -v virtual | grep -v sr | awk '{print($9)}' | awk '{if($0!="") print}'`
	OLD=$IFS
	IFS=$'\n'
	for devInfo in $devInfos; do 
	    devSN=`lsblk -o serial /dev/$devInfo | awk '{if(NR>1)print($0)}' | awk '{if($0!="") print}'`
	    devSNs=(${devSNs[@]} $devSN)
	done
}

#找到SN最大的返回
function dev_sort(){
	for ((j=0; j<${#devSNs[@]}-1; j++))
	do
		if [[ ${devSNs[j]} < ${devSNs[j+1]} ]]
		then
			#分别定义min为小值，MAX为大值
			min=${devSNs[j+1]}
			max=${devSNs[j]}
			#调整数组arr中数值顺序
			devSNs[j]=$min
			devSNs[j+1]=$max
		fi
	done
}

find_alldev
dev_sort
echo "${devSNs[0]}"