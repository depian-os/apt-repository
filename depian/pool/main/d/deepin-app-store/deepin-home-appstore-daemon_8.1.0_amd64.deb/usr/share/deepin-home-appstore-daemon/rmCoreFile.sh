#!/bin/bash

#set -x

# Get Rootb partition info
RootbPath=$(blkid -s LABEL -s TYPE | grep Rootb | awk -F ":" {'print $1'})
RootbType=$(blkid -s LABEL -s TYPE | grep Rootb | awk -F " " {'print $3'} | awk -F "\"" {'print $2'})
RootbMountPoint="/mnt/rootb"

# Mount Rootb and remove /core
if [ ! -d "$RootbMountPoint" ] ; then
	mkdir -p $RootbMountPoint
fi

if [ -n "$(grep $RootbMountPoint /proc/mounts)" ] ; then
	umount $RootbMountPoint
fi

if [ -n "$RootbPath" -a -n "$RootbType" ] ; then
	mount -t $RootbType $RootbPath $RootbMountPoint

	if [ -f "${RootbMountPoint}/core" ] ; then
		if [ $(file "${RootbMountPoint}/core" | grep deepin-home-appstore-daemon | wc -l) != 0 ] ; then
			rm ${RootbMountPoint}/core
		fi
	fi

	umount $RootbMountPoint
fi

if [ -d "$RootbMountPoint" -a -z "$(ls -A $RootbMountPoint)" ] ; then
	rm -rf $RootbMountPoint
fi

# Remove /core
if [ -f "/core" ] ; then
	if [ $(file "/core" | grep deepin-home-appstore-daemon | wc -l) != 0 ] ; then
		rm /core
	fi
fi

#read
