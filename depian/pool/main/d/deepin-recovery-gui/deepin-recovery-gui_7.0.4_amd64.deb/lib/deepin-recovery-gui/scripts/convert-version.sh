#!/bin/bash

err_mount_failed=10
err_umount_failed=11
err_fstable_not_exist=12
err_uuid_not_exist=13
err_invalid_mount_type=14

FSTABLE_PATH=
LOG_FILE=
LOG_LEVEL=
rootmnt=$1

TMP_APT_SOURCE_PATH=/tmp/tmp_apt_source_path/
APT_SOURCE_PATH=/etc/apt/sources.list
APT_SOURCE_LIST_D_PATH=/etc/apt/sources.list.d

for x in $(cat /proc/cmdline); do
    case $x in
        recovery.debug)
            LOG_LEVEL=debug
            ;;
    esac
done

init_log()
{
    local backup_dir_prefix="/tmp/deepin-recovery-live"
    local date=`date +"%Y%m%d_%H%M%S"`
    local logpath=${backup_dir_prefix}/log
    mkdir -p ${logpath}
    LOG_FILE="$logpath/restore-sys_$date.log"

    write_log "init_log, rootpath = ${rootmnt}, logpath = $logpath, LOG_FILE = $LOG_FILE"
}

copy_log()
{
    local log_dest_path=$1
    if [ x"$log_dest_path" = x ]; then
        # default log dest path
        log_dest_path=${rootmnt}/var/log/deepin/uos-recovery/restore/
    fi

    if [ ! -d $log_dest_path ]; then
        mkdir -p $log_dest_path
    fi

    cp -vrf $LOG_FILE $log_dest_path
    sync
    sync
    sync
}

dump_log()
{
    echo "dump log: "
    tail -n 50 $LOG_FILE
    echo "dump partition by lsblk:"
    echo "`lsblk -f`"
    sleep 15
}

write_log()
{
    if [ "$LOG_LEVEL" = "debug" ]; then
        echo "$1" | tee -a $LOG_FILE
        # 日志保存失败的话,加sleep方便在界面直接定位
        sleep 2
    else
        echo "$1" &>> $LOG_FILE
    fi
}

is_fstab_exist()
{
    FSTABLE_PATH=${rootmnt}/etc/fstab
    if [ ! -e "$FSTABLE_PATH" ]; then
        write_log "is_fstab_exist: $FSTABLE_PATH file not exist!"
        return $err_fstable_not_exist
    fi

    return 0
}


mount_fstab()
{
    local rootpath=${rootmnt}
    local fstable_path=$FSTABLE_PATH
    local logfile=$LOG_FILE
    write_log "mount_fstab: fstable_path = $fstable_path, rootpath = $rootpath, begin"
    local boot_uuid=
    local boot_mountpoint=
    local efi_uuid=
    local efi_mountpoint=

    while read fstabline; do
        # eg: UUID=bfc917ad-6f18-462b-af29-9bc823fd726d       /    ext4    rw,relatime    0 1
        if [ "${fstabline:0:5}" != "UUID=" ]; then
            continue
        fi

        fstype=$(echo "$fstabline" | awk '{print $3}')
        if [ $fstype = "swap" ]; then
            continue
        fi

        uuid=$(echo "$fstabline" | awk '{print $1}')
        if echo $uuid | grep -E -q "^UUID="; then
            uuid=$(echo "$uuid" | awk -F '=' '{print $2}')
        fi

        mountpoint=$(echo "$fstabline" | awk '{print $2}')
        if [ $mountpoint = "/" ]; then
            continue
        fi

        write_log  "fstype = $fstype, mountpoint = $mountpoint, uuid = $uuid"
        if [ $mountpoint = "/boot" ]; then
            boot_uuid=$uuid
            boot_mountpoint=$mountpoint
            continue
        fi

        if [ $mountpoint = "/boot/efi" ]; then
            efi_uuid=$uuid
            efi_mountpoint=$mountpoint
            continue
        fi

        if [ ! -e $rootpath$mountpoint ]; then
            write_log " Warnning! mount_fstab $rootpath$mountpoint not exit, create it "
            mkdir -p $rootpath$mountpoint
        fi

        mount -U $uuid $rootpath$mountpoint &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " mount_fstab mount error !, umount it, uuid=$uuid, mountPoint= $rootpath$mountpoint"
            umount $rootpath$mountpoint &>>$logfile
            write_log " mount_fstab mount again ... "
            mount -U $uuid $rootpath$mountpoint &>>$logfile
            #return $err_mount_failed
        fi
    done < "$fstable_path"

    # 先mount /boot
    if [ x"$boot_uuid" != x ]; then
        mount -U $boot_uuid $rootpath$boot_mountpoint &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " mount_fstab mount error !, umount it, boot_uuid=$boot_uuid, mountPoint= $rootpath$boot_mountpoint"
            umount $rootpath$boot_mountpoint &>>$logfile
            write_log " mount_fstab mount again ... "
            mount -U $boot_uuid $rootpath$boot_mountpoint &>>$logfile
        fi
    fi

    if [ x"$efi_uuid" != x ]; then
        mount -U $efi_uuid $rootpath$efi_mountpoint &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " mount_fstab mount error !, umount it, efi_uuid=$efi_uuid, efi_mountpoint= $rootpath$efi_mountpoint"
            umount $rootpath$efi_mountpoint &>>$logfile
            write_log " mount_fstab mount again ... "
            mount -U $efi_uuid $rootpath$efi_mountpoint &>>$logfile
        fi
    fi

    mount_bind
    local errcode=$?
    if [ $errcode -ne 0 ]; then
        write_log " mount_fstab: mount_bind error, rootpath = $rootpath, errcode = $errcode"
        return $errcode
    fi

    return 0
}

umount_fstab()
{
    local rootpath=${rootmnt}
    local fstable_path=$FSTABLE_PATH
    local logfile=$LOG_FILE
    local boot_mountpoint=
    local efi_mountpoint=

    umount_bind
    local errcode=$?
    if [ $errcode -ne 0 ]; then
        write_log " umount_fstab: umount_bind error, rootpath = $rootpath, errcode = $errcode"
        return $errcode
    fi
    write_log "umount_fstab: fstable_path = $fstable_path, rootpath = $rootpath, begin"

    while read fstabline; do
        # eg: UUID=bfc917ad-6f18-462b-af29-9bc823fd726d       /    ext4    rw,relatime    0 1
        if [ "${fstabline:0:5}" != "UUID=" ]; then
            continue
        fi

        mountpoint=$(echo "$fstabline" | awk '{print $2}')
        if [ $mountpoint = "/" ]; then
            continue
        fi

        fstype=$(echo "$fstabline" | awk '{print $3}')
        if [ $fstype = "swap" ]; then
            continue
        fi

        write_log "fstype = $fstype, mountpoint = $mountpoint"
        if [ $mountpoint = "/boot" ]; then
            boot_mountpoint=$mountpoint
            continue
        fi

        if [ $mountpoint = "/boot/efi" ]; then
            efi_mountpoint=$mountpoint
            continue
        fi

        if [ ! -e $rootpath$mountpoint ]; then
            write_log " Warnning! umount_fstab $rootpath$mountpoint not exit "
            continue
        fi

        umount $rootpath$mountpoint &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " umount_fstab umount error !, exit "
            return $err_umount_failed
        fi
    done < "$fstable_path"

    # 先卸载 /boot/efi, 后卸载 /boot
    if [ x"$efi_mountpoint" != x ]; then
        umount $rootpath$efi_mountpoint &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " umount_fstab umount error !, efi_mountpoint= $rootpath$efi_mountpoint"
            return $err_umount_failed
        fi
    fi

    if [ x"$boot_mountpoint" != x ]; then
        umount $rootpath$boot_mountpoint &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " umount_fstab umount error !, boot_mountpoint= $rootpath$boot_mountpoint"
            return $err_umount_failed
        fi
    fi

    return 0
}

mount_bind()
{
    local rootpath=${rootmnt}
    local fstable_path=$FSTABLE_PATH
    local logfile=$LOG_FILE
    write_log "mount_bind: fstable_path= $fstable_path, rootpath=$rootpath"

    while read fstabline; do
        # eg: /data/home /home none defaults,bind 0 0
        if [ "${fstabline:0:1}" != "/" ]; then
            continue
        fi

        bind_flag=$(echo "$fstabline" | awk -F ',' '{print $2}' | awk '{print $1}')
        write_log "mount_bind: fstabline: $fstabline, bind_flag= $bind_flag"
        if [ "${bind_flag}" != "bind" ]; then
            continue
        fi
        olddir=$(echo "$fstabline" | awk '{print $1}')
        newdir=$(echo "$fstabline" | awk '{print $2}')

        write_log "mount_bind: bind_flag = $bind_flag, olddir = $olddir, newdir = $newdir"
        if [ ! -e $rootpath$newdir ]; then
            write_log " Warnning! mount_bind $rootpath$newdir not exit , create it"
            mkdir -p $rootpath$newdir
        fi

        mount --bind $rootpath$olddir $rootpath$newdir &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " mount_bind mount --bind error !, exit "
            return $err_mount_failed
        fi
    done < "$fstable_path"

    return 0
}

umount_bind()
{
    local rootpath=${rootmnt}
    local fstable_path=$FSTABLE_PATH
    local logfile=$LOG_FILE
    write_log "umount_bind: fstable_path= $fstable_path, rootpath=$rootpath"

    while read fstabline; do
        # eg: /data/home /home none defaults,bind 0 0
        if [ "${fstabline:0:1}" != "/" ]; then
            continue
        fi

        bind_flag=$(echo "$fstabline" | awk -F ',' '{print $2}' | awk '{print $1}')
        write_log "umount_bind: fstabline: $fstabline, bind_flag= $bind_flag"
        if [ "${bind_flag}" != "bind" ]; then
            continue
        fi
        olddir=$(echo "$fstabline" | awk '{print $1}')
        newdir=$(echo "$fstabline" | awk '{print $2}')

        write_log "umount_bind: bind_flag = $bind_flag, olddir = $olddir, newdir = $newdir"

        if [ ! -e $rootpath$newdir ]; then
            write_log " Warnning! umount_bind $rootpath$newdir not exit "
            continue
        fi
        umount $rootpath$newdir &>>$logfile
        if [ $? -ne 0 ]; then
            write_log " umount_bind umount error !, exit "
            return $err_umount_failed
        fi
    done < "$fstable_path"

    return 0
}

ini_get()
{
    local file_path=$1
    local section=$2
    local key=$3

    local val=$(awk -F "=" '/\['${section}'\]/{a=1}a==1&&$1~/'${key}'/{print $2;exit}' $file_path)
    echo $val
}

setup_repo_sources()
{
    # 本地仓库的路径
    local rootpath=${rootmnt}
    local PRO_EDU_PPA_PATH=/media/pro-edu-ppa
    local LIVE_DIR=${rootpath}${PRO_EDU_PPA_PATH}
    local LOC_REPO_PATH=$LIVE_DIR/dists
    # add cdrom to sources.list
    if [ -d $LOC_REPO_PATH ]; then
        dir=$(find $LOC_REPO_PATH -name "Release" | xargs awk -F '[ :]+' '/Codename/{print $2}')
        for name in $dir; do
            # ident the cdrom first.
            echo "deb [trusted=yes] file:${PRO_EDU_PPA_PATH} ${name} main" >> ${rootpath}/etc/apt/sources.list.d/deepin-recovery-live.list
        done

        apt-get update || true
    else
        write_log "$LOC_REPO_PATH is not a debian repository. Skipped."
    fi
    write_log "cat ${rootpath}/etc/apt/sources.list.d/deepin-recovery-live.list"
    write_log "`cat ${rootpath}/etc/apt/sources.list.d/deepin-recovery-live.list`"
    write_log "setup_repo_sources end"
}

backup_apt_source()
{
    local rootpath=${rootmnt}
    mkdir -p $TMP_APT_SOURCE_PATH
    write_log "`ls -l $TMP_APT_SOURCE_PATH`"
    rm -rf ${rootpath}/etc/apt/sources.list.d/deepin-recovery-live.list
    mv ${rootpath}${APT_SOURCE_PATH} $TMP_APT_SOURCE_PATH
    mv ${rootpath}${APT_SOURCE_LIST_D_PATH} $TMP_APT_SOURCE_PATH
    mkdir -p ${rootpath}/etc/apt/sources.list.d/
    write_log "`ls -l $TMP_APT_SOURCE_PATH`"
    write_log "echo ls -l /etc/apt/"
    write_log "`ls -l ${rootpath}${APT_SOURCE_PATH}`"
    write_log "`ls -l ${rootpath}${APT_SOURCE_LIST_D_PATH}/`"
}

restore_apt_source()
{
    local rootpath=${rootmnt}
    rm -rf ${rootpath}${APT_SOURCE_PATH}
    rm -rf ${rootpath}${APT_SOURCE_LIST_D_PATH}
    write_log "restore rootpath: ${rootpath}"
    write_log "`lsblk -f`"
    cp -rRf $TMP_APT_SOURCE_PATH/* ${rootpath}/etc/apt/
    write_log "restore echo ls -l /etc/apt/"
    write_log "`ls -l ${rootpath}${APT_SOURCE_PATH}`"
    write_log "`ls -l ${rootpath}${APT_SOURCE_LIST_D_PATH}/`"
}

convert-professional2education()
{
    local rootpath=${rootmnt}
    local logfile=$LOG_FILE

    is_fstab_exist
    local errcode=$?
    if [ $errcode -ne 0 ]; then
        write_log " convert: is_fstab_exist error, rootpath = $rootpath, errcode = $errcode"
        return $errcode
    fi

    mount_fstab
    errcode=$?
    if [ $errcode -ne 0 ]; then
        write_log " convert call mount_type=$mount_type error!, errcode = $errcode "
        return $errcode
    fi
    write_log "`lsblk -f`"

    mount --bind -v --bind /dev/ $rootpath/dev
    mount -vt proc proc $rootpath/proc
    mount -vt sysfs sysfs $rootpath/sys
    mount --bind /run $rootpath/run
    backup_apt_source
    setup_repo_sources
    write_log "ls -l ${rootpath}/etc/apt/sources.list.d/"
    write_log "`ls -l ${rootpath}/etc/apt/sources.list.d/`"
    chroot $rootpath apt-get update || true
    chroot $rootpath apt-get -y --allow-downgrades -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" --no-install-recommends --allow-unauthenticated install deepin-edu-base || true
    write_log "chroot install deepin-edu-base end"
    restore_apt_source
    rm -rf ${rootpath}/media/pro-edu-ppa
    sync
    umount $rootpath/dev
    umount $rootpath/proc
    umount $rootpath/sys
    umount $rootpath/run
    write_log "restore_apt_source end"
    umount_fstab
    errcode=$?
    if [ $errcode -ne 0 ]; then
        write_log "main umount_fstab error!, errcode = $errcode "
        return $errcode
    fi

    write_log "`lsblk -f`"
}

main()
{
    init_log
    convert-professional2education
    local errcode=$?
    copy_log
    return $errcode
}

main
retcode=$?
exit $retcode
