#! /bin/bash

ACTIVE_SCREEN_NUM=
PRIMARY_MODE=
PRIMARY_PREFERRED_MODE=
PRIMARY_CURRENT_MODE=
XRANDR_MODE=
IS_HUAWEI_KLVX="false"
IS_HUAWEI_PGX="false"
HUAWEI_MODE="2160x1440"
SCALE=

LOG_FILE=
LOG_LEVEL=

init_log()
{
    local backup_dir_prefix="/tmp/recovery"
    local date=`date +"%Y%m%d_%H%M%S"`
    local logpath=${backup_dir_prefix}/log
    mkdir -p ${logpath}
    LOG_FILE="$logpath/deepin-recovery-screen_$date.log"
}

write_log()
{
    if [ "$LOG_LEVEL" = "debug" ]; then
        echo "$1" | tee -a $LOG_FILE
        # 日志保存失败的话,加sleep方便在界面直接定位
        sleep 5
    else
        echo "$1" &>> $LOG_FILE
    fi
}

get_preferred_mode()
{
    local mode=`xrandr -q | grep + | awk '{print $1}' | grep -E [0-9]+x[0-9] | sed -n 1p`
    PRIMARY_PREFERRED_MODE=$mode
}

get_current_mode()
{
    local mode=`xrandr -q | grep [*] | awk '{print $1}' | grep -E [0-9]+x[0-9] | sed -n 1p`
    PRIMARY_CURRENT_MODE=$mode
}

get_device_type()
{
    local system_product_name=$(sudo dmidecode -s system-product-name | awk '{print $NF}')
    local HUAWEI_TYPE=$(sudo dmidecode | grep -i “String 4”| awk '{print $3}')
    case "$HUAWEI_TYPE" in
        PWC30*)
            system_product_name="PGUW"
            ;;
        PGUX*)
            system_product_name="PGUX"
            ;;
    esac

    case "$system_product_name" in
        KLVV*|KLVU*)
            IS_HUAWEI_KLVX="true"
            ;;
        PGUV*|PGUW*|PGUX*)
            IS_HUAWEI_PGX="true"
    esac
}

get_active_screen_num()
{
    local connectedScreenNum=`xrandr | grep ' connected ' | wc -l`
    ACTIVE_SCREEN_NUM=${connectedScreenNum:-0}
    echo "get_active_screen_num: ACTIVE_SCREEN_NUM = " ${ACTIVE_SCREEN_NUM}
}

get_xrandr_mode()
{
    local active_screen_nums=$1
    local mini_mode="800x600";
    local default_mode="1920x1080";
    local huawei_klv_default_mode="2160x1440"
    local preferred_mode="1024x768";
    local support_num=
    local mode_list=
    local mode_support_num=

    if [ x"$IS_HUAWEI_KLVX" = xtrue ]; then
        support_num=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+ | grep -E "^$huawei_klv_default_mode$" | wc -l`
        if [ $support_num -eq ${active_screen_nums} ]; then
            PRIMARY_MODE=$huawei_klv_default_mode
            XRANDR_MODE=$huawei_klv_default_mode
            SCALE="0.75x0.75"
            return
        else
            if [ $support_num -ge 1 ]; then
                PRIMARY_MODE=$huawei_klv_default_mode
                SCALE="0.75x0.75"
            fi
            mode_list=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+`
            for mode in $mode_list; do
               mode_support_num=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+ | grep -E "^$mode$" | wc -l`
               if [ $mode_support_num -eq ${active_screen_nums} ]; then
                   XRANDR_MODE=$mode
                   return;
               fi
            done
        fi
    elif [ x"$IS_HUAWEI_PGX" = xtrue ]; then
        support_num=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+ | grep -E "^$default_mode$" | wc -l`
        if [ $support_num -eq ${active_screen_nums} ]; then
            PRIMARY_MODE=$default_mode
            XRANDR_MODE=$default_mode
            if [ x"$preferred_mode" = x"$PRIMARY_PREFERRED_MODE" ]; then
                PRIMARY_MODE=$preferred_mode
                write_log "pgx PRIMARY_MODE = preferred_mode: $preferred_mode"
            else
                if [ x"$PRIMARY_PREFERRED_MODE" != x ]; then
                    PRIMARY_MODE=$PRIMARY_PREFERRED_MODE
                else
                    PRIMARY_MODE=$PRIMARY_CURRENT_MODE
                fi
                write_log "pgx PRIMARY_MODE = $PRIMARY_MODE"
            fi
            return
        else
            if [ $support_num -ge 1 ]; then
                PRIMARY_MODE=$default_mode
                if [ x"$preferred_mode" = x"$PRIMARY_PREFERRED_MODE" ]; then
                    PRIMARY_MODE=$preferred_mode
                    write_log "pgx support_num=$support_num PRIMARY_MODE= $preferred_mode"
                else
                    if [ x"$PRIMARY_PREFERRED_MODE" != x ]; then
                        PRIMARY_MODE=$PRIMARY_PREFERRED_MODE
                    else
                        PRIMARY_MODE=$PRIMARY_CURRENT_MODE
                    fi
                    write_log "pgx 2 PRIMARY_MODE = $PRIMARY_MODE"
                fi
            fi
            mode_list=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+`
            for mode in $mode_list; do
               mode_support_num=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+ | grep -E "^$mode$" | wc -l`
               if [ $mode_support_num -eq ${active_screen_nums} ]; then
                   XRANDR_MODE=$mode
                   return;
               fi
            done
        fi
    else
        support_num=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+ | grep -E "^$default_mode$" | wc -l`
        if [ $support_num -eq ${active_screen_nums} ]; then
            XRANDR_MODE=$default_mode
            if [ x"$preferred_mode" = x"$PRIMARY_PREFERRED_MODE" ]; then
                XRANDR_MODE=$preferred_mode
                write_log "not klvx and pgx: XRANDR_MODE = $preferred_mode, support_num = $support_num"
            fi
            SCALE=
            return;
        else
            mode_list=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+`
            for mode in $mode_list; do
               mode_support_num=`xrandr -q | awk '{print $1}' | grep -E [0-9]+x[0-9]+ | grep -E "^$mode$" | wc -l`
               if [ $mode_support_num -eq ${active_screen_nums} ]; then
                   XRANDR_MODE=$mode
                   SCALE=
                   return;
               fi
           done
        fi
    fi

    PRIMARY_MODE=$mini_mode
    XRANDR_MODE=$mini_mode
}

auto_adapter_screen()
{
    init_log
    get_device_type
    get_active_screen_num
    get_preferred_mode
    get_current_mode
    get_xrandr_mode ${ACTIVE_SCREEN_NUM}

    local disConnectedScreens=`xrandr | grep ' disconnected ' | awk '{print $1}'`
    local connectedScreenList=`xrandr | grep ' connected ' | grep -v ' connected primary ' | awk '{print $1}'`
    local primaryScreen=`xrandr | grep ' connected primary ' | awk '{print $1}'`
    local preferred_mode="1024x768";
    write_log "`xrandr`"
    write_log "PRIMARY_PREFERRED_MODE = $PRIMARY_PREFERRED_MODE, PRIMARY_CURRENT_MODE = $PRIMARY_CURRENT_MODE"
    write_log "primaryScreen = $primaryScreen, XRANDR_MODE = $XRANDR_MODE, SCALE = $SCALE, IS_HUAWEI_KLVX = $IS_HUAWEI_KLVX"
    write_log "PRIMARY_MODE = $PRIMARY_MODE, connectedScreenList = $connectedScreenList, disConnectedScreens = $disConnectedScreens"
    if [ x"$primaryScreen" != x ]; then
        if [ x"$IS_HUAWEI_KLVX" = xtrue ] || [ x"$IS_HUAWEI_PGX" = xtrue ]; then
            for disScreen in $disConnectedScreens; do
                xrandr --output $disScreen --off
            done
            if [ ${ACTIVE_SCREEN_NUM} -ne 1 ]; then
                for screen in $connectedScreenList; do
                    xrandr --output $screen --same-as $primaryScreen --mode $XRANDR_MODE
                done

                xrandr --output $primaryScreen --off
                if [ x"$IS_HUAWEI_KLVX" = xtrue ]; then
                    xrandr --output $primaryScreen --primary --mode $PRIMARY_MODE --scale 1x1
                else
                    xrandr --output $primaryScreen --primary --mode $PRIMARY_MODE
                fi
            fi

            if [ x"$IS_HUAWEI_KLVX" = xtrue ]; then
                write_log "klvx set primaryScreen: $primaryScreen, PRIMARY_MODE = $PRIMARY_MODE, SCALE = $SCALE"
                xrandr --output $primaryScreen --primary --mode $PRIMARY_MODE --scale $SCALE
            else
                write_log "pgx set primaryScreen: $primaryScreen, PRIMARY_MODE = $PRIMARY_MODE"
                xrandr --output $primaryScreen --primary --mode $PRIMARY_MODE
            fi
        else
            write_log "set primaryScreen: $primaryScreen, PRIMARY_MODE = $PRIMARY_MODE"
            xrandr --output $primaryScreen --primary --mode $XRANDR_MODE
        fi

        for screen in $connectedScreenList; do
            local preferred=`xrandr -q | grep + | awk '/'$screen'/{getline line; print line}' | grep -E [0-9]+x[0-9]+ |awk '{print $1}'`
            if [ x"$preferred_mode" = x"$preferred" ]; then
                xrandr --output $screen --same-as $primaryScreen --mode $preferred --scale 1.6x1.6
                write_log "screen = $screen, preferred=$preferred, XRANDR_MODE=$XRANDR_MODE"
            else
                xrandr --output $screen --same-as $primaryScreen --mode $XRANDR_MODE
                write_log "screen = $screen, primaryScreen=$primaryScreen, XRANDR_MODE=$XRANDR_MODE"
            fi
        done
    else
        for screen in $connectedScreenList; do
            local resolution=`xrandr -q | awk '/'$screen'/{getline line; print line}' | grep -E [0-9]+x[0-9]+ |awk '{print $1}'`
            #xrandr --output $screen --mode $XRANDR_MODE
            write_log "primaryScreen is null, set $screen mode: XRANDR_MODE = $XRANDR_MODE, ACTIVE_SCREEN_NUM = $ACTIVE_SCREEN_NUM"
            if [ ${ACTIVE_SCREEN_NUM} -eq 1 ]; then
                get_preferred_mode
                if [ x"$IS_HUAWEI_PGX" = xtrue ]; then
                    xrandr --output $screen --primary --mode $PRIMARY_CURRENT_MODE
                    write_log "pgx primaryScreen is null, set $screen mode: PRIMARY_CURRENT_MODE = $PRIMARY_CURRENT_MODE, PRIMARY_PREFERRED_MODE= $PRIMARY_PREFERRED_MODE"
                else
                    if [ x"$preferred_mode" = x"$PRIMARY_PREFERRED_MODE" ]; then
                        xrandr --output $screen --primary --mode $preferred_mode
                        write_log "primaryScreen is null, set $screen mode: PRIMARY_CURRENT_MODE = $PRIMARY_CURRENT_MODE, PRIMARY_PREFERRED_MODE= $PRIMARY_PREFERRED_MODE"
                    else
                        xrandr --output $screen --primary --mode $XRANDR_MODE
                        write_log "preferred_mode = $preferred_mode, PRIMARY_PREFERRED_MODE = $PRIMARY_PREFERRED_MODE, XRANDR_MODE = $XRANDR_MODE"
                    fi
                fi
            else
                xrandr --output $screen --mode $XRANDR_MODE
                write_log "ACTIVE_SCREEN_NUM=$ACTIVE_SCREEN_NUM, resolution=$resolution"
            fi
        done
    fi
}

auto_adapter_screen
