// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

#define DTKDECLARATIVE_CLASS_DAppLoader
#define DTKDECLARATIVE_CLASS_DQmlAppMainWindowInterface
#define DTKDECLARATIVE_CLASS_DQmlAppPreloadInterface
#define DTKDECLARATIVE_CLASS_DQuickBlitFramebuffer
#define DTKDECLARATIVE_CLASS_DQuickItemViewport
#define DTKDECLARATIVE_CLASS_DQuickWindow
#define DTKDECLARATIVE_CLASS_DPlatformThemeProxy
#define DTKDECLARATIVE_CLASS_DQuickSystemPalette
