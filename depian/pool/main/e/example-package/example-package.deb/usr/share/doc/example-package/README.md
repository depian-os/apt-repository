Example Package
==============

This is an example package to demonstrate how to add packages to your
personal APT repository hosted on GitHub Pages.

Installation
------------
Run the following command to install this package:

    sudo apt-get install example-package

Usage
-----
After installation, you can run:

    example-script

This will display a greeting message from the example package.