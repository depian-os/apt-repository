/*
 * Copyright (C) 2020 ~ 2021 Uniontech Software Technology Co., Ltd.
 *
 * Author:     xushitong<xushitong@uniontech.com>
 *
 * Maintainer: max-lv<lvwujun@uniontech.com>
 *             lanxuesong<lanxuesong@uniontech.com>
 *             zhangsheng<zhangsheng@uniontech.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef UDFBURN_H
#define UDFBURN_H

typedef struct {
    int start_of_last_session;
    int next_writable_address;
    int free_blocks;
} CParam;

typedef struct {
    long total_size;
    long wrote_size;
    double progress;
} ProgressInfo;

typedef void (*progress_cb)(const ProgressInfo *);

void    burn_init();
CParam  burn_get_c_param(const char *device);
char   *burn_get_media_type(const char *device);
int     burn_burn_to_disc(const char *device, const char *file, const char *label);
void    burn_eject_disc(const char *device);
void    burn_show_verbose_information();
void    burn_redirect_output(int redirect_stdout, int redirect_stderr);
void    burn_register_progress_callback(progress_cb callback);
char  **burn_get_last_errors(int *count);

#endif
